/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarAccessories;

/**
 *
 * @author Ankit Adahakari, Kushal Niraula, Tyagi Sen
 * Initialized all 
 */
    public class CarAccessories {
    private String id, name, category, range;
    int price;
    public CarAccessories(String id, String name, String category, int price, String range){
        this.id=id;
        this.name=name;
        this.category=category;
        this.price=price;
        this.range=range;
        
    }
    public String getId(){//This method returns the Id
        return id;
        
    }
    public String getName(){// This method returns the Accessories name
        return name;
        
    }
    public String getCategory(){// This method returns the category.
        return category;
        
    }
    public int getPrice(){// This method returns the price.
        return price;
        
    }
    public String getRange(){// This method return the range.
        return range;
        
    }

}
